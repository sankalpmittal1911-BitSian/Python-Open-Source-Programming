import logging

logger = logging.getLogger(__name__)


class Dolores(object):

    # Built-in words
    DOLORES_COGNATES = ["dolores", "dolares", "solores", "dervis", "service"]

    STOP_LISTENING_COGNATES = ["go away", "stop listening", "shut down"]

    @classmethod
    def is_actionable_command(cls, command):
        return any(cognate in command for cognate in cls.DOLORES_COGNATES)

    @classmethod
    def handle_action(cls, command, **kwargs):
        """
        Handles a single text command.
        """

        # Use lowercase for processing.
        command = command.lower()

        logger.debug("Received command: '%s'", command)

        # Determine if this is an actionable command.
        if not cls.is_actionable_command(command):
            return

        if any(cognate in command for cognate in cls.STOP_LISTENING_COGNATES):
            logger.info("Thank you, enjoy your day, sir.")
        else:
            logger.info("Yes sir?")